import random
from termcolor import colored


def printBoard():
    print(colored(playerOneStarter + " " * playerOnePosition + "*", "red"))
    print(colored(board, "cyan"))
    print(colored(playerTwoStarter + " " * playerTwoPosition + "*", "blue"))


# strings you'll use to describe the board....
#                   12345678901234567890123456789012345678901234567890123456789012345678901234567890
board = "          +--------------------------------------------------------------------------------+\n          |-----A--B---C----D-------A--B---C----D-------A--B---C----D-------A--B---C----D--|\n          +--------------------------------------------------------------------------------+"
playerOneStarter = "Player 1: "
playerTwoStarter = "Player 2: "
playerOnePosition = 0
playerTwoPosition = 0
# Information about which chips player 1 has collected.
playerOneChips = 0
playerOneAText = ""
playerOneBText = ""
playerOneCText = ""
playerOneDText = ""
# Information about which chips player 2 has collected.
playerTwoChips = 0
playerTwoAText = ""
playerTwoBText = ""
playerTwoCText = ""
playerTwoDText = ""

print(colored("Welcome to Collect Four (not to be confused with Connect Four).\nA two player game will now begin.\n", "cyan"))

while True:
    dummy1 = raw_input(colored("Player One, please press the return key to roll the dice.\n", "cyan"))
    playerOneMove = random.randrange(2, 12)
    playerOnePosition += playerOneMove
    print(colored("Player One rolls a {0}.\n".format(playerOneMove), "red"))
    if playerOnePosition % 20 == 6:
        playerOneChips |= 1
        playerOneAText = "A "
    if playerOnePosition % 20 == 9:
        playerOneChips |= 2
        playerOneBText = "B "
    if playerOnePosition % 20 == 13:
        playerOneChips |= 4
        playerOneCText = "C "
    if playerOnePosition % 20 == 18:
        playerOneChips |= 8
        playerOneDText = "D "
    if playerOnePosition > 80:
        playerOnePosition %= 80

    printBoard()

    print(colored("\nPlayer One Has: {0}{1}{2}{3}\n".format(playerOneAText, playerOneBText, playerOneCText, playerOneDText), "red"))

    if playerOneChips == 15:
        print(colored("Player One Wins! Game Over. Get good m79+1.", "yellow"))
        break

    print(colored("+-----------------------------------------------------------------------------------------+\n", "cyan"))

    dummy2 = raw_input(colored("Player Two, please press the return key to roll the dice.\n", "cyan"))
    playerTwoMove = random.randrange(2, 12)
    playerTwoPosition += playerTwoMove
    print(colored("Player Two rolls a {0}.".format(playerOneMove), "blue"))
    if playerTwoPosition % 20 == 6:
        playerTwoChips |= 1
        playerTwoAText = "A "
    if playerTwoPosition % 20 == 9:
        playerTwoChips |= 2
        playerTwoBText = "B "
    if playerTwoPosition % 20 == 13:
        playerTwoChips |= 4
        playerTwoCText = "C "
    if playerTwoPosition % 20 == 18:
        playerTwoChips |= 8
        playerTwoDText = "D "
    if playerTwoPosition > 80:
        playerTwoPosition %= 80

    printBoard()

    print(colored("\nPlayer Two Has: {0}{1}{2}{3}\n".format(playerTwoAText, playerTwoBText, playerTwoCText, playerTwoDText), "blue"))

    if playerTwoChips == 15:
        print(colored("Player Two Wins! Game Over. Get good m81-1.", "yellow"))
        break
    print(colored("+-----------------------------------------------------------------------------------------+\n", "cyan"))
