import random

# strings you'll use to describe the board....
#                   12345678901234567890123456789012345678901234567890123456789012345678901234567890
board = "           -----A--B---C----D-------A--B---C----D-------A--B---C----D-------A--B---C----D--"
playerOneStarter = "Player 1: "
playerTwoStarter = "Player 2: "
playerThreeStarter = "PLayer 3:"
playerFourStarter = "PLayer 4"
playerOnePosition = 1
playerTwoPosition = 1
playerThreePosition = 1
playerFourPosition = 1
twoPlayers = False
threePlayers = False
fourPlayers = False
# Information about which chips player 1 has collected.
playerOneHasA = False
playerOneAText = ""
playerOneHasB = False
playerOneBText = ""
playerOneHasC = False
playerOneCText = ""
playerOneHasD = False
playerOneDText = ""
# Information about which chips player 2 has collected.
playerTwoHasA = False
playerTwoAText = ""
playerTwoHasB = False
playerTwoBText = ""
playerTwoHasC = False
playerTwoCText = ""
playerTwoHasD = False
playerTwoDText = ""
# Information about which chips player 3 has collected.
playerThreeHasA = False
playerThreeAText = ""
playerThreeHasB = False
playerThreeBText = ""
playerThreeHasC = False
playerThreeCText = ""
playerThreeHasD = False
playerThreeDText = ""
# Information about which chips player 4 has collected.
playerFourHasA = False
playerFourAText = ""
playerFourHasB = False
playerFourBText = ""
playerFourHasC = False
playerFourCText = ""
playerFourHasD = False
playerFourDText = ""

print"Welcome to Collect Four (not to be confused with Connect Four)."

playerNumber = raw_input("Please input number of players (2-4).")
if playerNumber == 2 or "two":
    twoPlayers = True
if playerNumber == 3 or "three":
    threePlayers = True
if playerNumber == 4 or "four":
    fourPlayers = True

print"The {0} player game will now begin.".format(playerNumber)

while twoPlayers:
    dummy1 = raw_input("Player One, please hit the return key to roll the die.")
    playerOneMove = random.randrange(2, 12)
    playerOnePosition += playerOneMove
    print"Player One rolls a {0}".format(playerOneMove)
    if playerOnePosition % 20 == 6:
        playerOneHasA = True
        playerOneAText = "A "
    if playerOnePosition % 20 == 9:
        playerOneHasB = True
        playerOneBText = "B "
    if playerOnePosition % 20 == 13:
        playerOneHasC = True
        playerOneCText = "C "
    if playerOnePosition % 20 == 18:
        playerOneHasD = True
        playerOneDText = "D "
    if playerOnePosition > 80:
        playerOnePosition %= 80

    print"Player One Has: {0}{1}{2}{3}".format(playerOneAText, playerOneBText, playerOneCText, playerOneDText)

    if playerOnePosition == playerTwoPosition:
        playerTwoPosition = 1
        playerOneHasA = False
        playerOneAText = ""
        playerOneHasB = False
        playerOneBText = ""
        playerOneHasC = False
        playerOneCText = ""
        playerOneHAsD = False
        playerOneDText = ""
        print "Player Two Has Bumped player one back to the first space! Player One Loses all letters!"

    print playerOneStarter + " " * playerOnePosition + "*"
    print board
    print playerTwoStarter + " " * playerTwoPosition + "*"

    if playerOneHasA and playerOneHasB and playerOneHasC and playerOneHasD:
        print"Player One wins!"
        print"Game Over"
        break

    dummy2 = raw_input("Player Two, please hit the return key to roll the die.")
    playerTwoMove = random.randrange(2, 12)
    playerTwoPosition += playerTwoMove
    print"Player Two rolls a {0}".format(playerTwoMove)
    if playerTwoPosition % 20 == 6:
        playerTwoHasA = True
        playerTwoAText = "A "
    if playerTwoPosition % 20 == 9:
        playerTwoHasB = True
        playerTwoBText = "B "
    if playerTwoPosition % 20 == 13:
        playerTwoHasC = True
        playerTwoCText = "C "
    if playerTwoPosition % 20 == 18:
        playerTwoHasD = True
        playerTwoDText = "D "
    if playerTwoPosition > 80:
        playerTwoPosition %= 80

    print"Player Two Has: {0}{1}{2}{3}".format(playerTwoAText, playerTwoBText, playerTwoCText, playerTwoDText)

    if playerTwoPosition == playerOnePosition:
        playerOnePosition = 1
        playerTwoHasA = False
        playerTwoAText = ""
        playerTwoHasB = False
        playerTwoBText = ""
        playerTwoHasC = False
        playerTwoCText = ""
        playerTwoHAsD = False
        playerTwoDText = ""
        print "Player Two Has Bumped player one back to the first space! Player One Loses all letters!"

    print playerOneStarter + " " * playerOnePosition + "*"
    print board
    print playerTwoStarter + " " * playerTwoPosition + "*"

    if playerTwoHasA and playerTwoHasB and playerTwoHasC and playerTwoHasD:
        print"Player One wins!"
        print"Game Over"
        break

# ----------------------------------------------------------------------------------------------------------------------

while threePlayers:
    dummy11 = raw_input("Player One, please hit the return key to roll the die.")
    playerOneMove = random.randrange(2, 12)
    playerOnePosition += playerOneMove
    print"Player One rolls a {0}".format(playerOneMove)
    if playerOnePosition % 20 == 6:
        playerOneHasA = True
        playerOneAText = "A "
    if playerOnePosition % 20 == 9:
        playerOneHasB = True
        playerOneBText = "B "
    if playerOnePosition % 20 == 13:
        playerOneHasC = True
        playerOneCText = "C "
    if playerOnePosition % 20 == 18:
        playerOneHasD = True
        playerOneDText = "D "
    if playerOnePosition > 80:
        playerOnePosition %= 80

    print"Player One Has: {0}{1}{2}{3}".format(playerOneAText, playerOneBText, playerOneCText, playerOneDText)

    if playerOnePosition == playerTwoPosition:
        playerTwoPosition = 1
        playerTwoHasA = False
        playerTwoAText = ""
        playerTwoHasB = False
        playerTwoBText = ""
        playerTwoHasC = False
        playerTwoCText = ""
        playerTwoHAsD = False
        playerTwoDText = ""
        print "Player Two Has Bumped player one back to the first space! Player One Loses all letters!"

    if playerOnePosition == playerThreePosition:
        playerThreePosition = 1
        playerThreeHasA = False
        playerThreeAText = ""
        playerThreeHasB = False
        playerThreeBText = ""
        playerThreeHasC = False
        playerThreeCText = ""
        playerThreeHAsD = False
        playerThreeDText = ""
        print "Player One Has Bumped player Three back to the first space! Player Three Loses all letters!"

    print playerOneStarter + " " * playerOnePosition + "*"
    print board
    print playerTwoStarter + " " * playerTwoPosition + "*"
    print playerThreeStarter + " " * playerThreePosition + "*"

    if playerOneHasA and playerOneHasB and playerOneHasC and playerOneHasD:
        print"Player One wins!"
        print"Game Over"
        break

    dummy21 = raw_input("Player Two, please hit the return key to roll the die.")
    playerTwoMove = random.randrange(2, 12)
    playerTwoPosition += playerTwoMove
    print"Player Two rolls a {0}".format(playerTwoMove)
    if playerTwoPosition % 20 == 6:
        playerTwoHasA = True
        playerTwoAText = "A "
    if playerTwoPosition % 20 == 9:
        playerTwoHasB = True
        playerTwoBText = "B "
    if playerTwoPosition % 20 == 13:
        playerTwoHasC = True
        playerTwoCText = "C "
    if playerTwoPosition % 20 == 18:
        playerTwoHasD = True
        playerTwoDText = "D "
    if playerTwoPosition > 80:
        playerTwoPosition %= 80

    print"Player Two Has: {0}{1}{2}{3}".format(playerTwoAText, playerTwoBText, playerTwoCText, playerTwoDText)

    if playerTwoPosition == playerOnePosition:
        playerOnePosition = 1
        playerOneHasA = False
        playerOneAText = ""
        playerOneHasB = False
        playerOneBText = ""
        playerOneHasC = False
        playerOneCText = ""
        playerOneHAsD = False
        playerOneDText = ""
        print "Player Two Has Bumped player one back to the first space! Player One Loses all letters!"

    if playerTwoPosition == playerThreePosition:
        playerThreePosition = 1
        playerThreeHasA = False
        playerThreeAText = ""
        playerThreeHasB = False
        playerThreeBText = ""
        playerThreeHasC = False
        playerThreeCText = ""
        playerThreeHAsD = False
        playerThreeDText = ""
        print "Player Two Has Bumped player Three back to the first space! Player Three Loses all letters!"

    print playerOneStarter + " " * playerOnePosition + "*"
    print board
    print playerTwoStarter + " " * playerTwoPosition + "*"
    print playerThreeStarter + " " * playerThreePosition + "*"

    if playerTwoHasA and playerTwoHasB and playerTwoHasC and playerTwoHasD:
        print"Player Two wins!"
        print"Game Over"
        break

    dummy31 = raw_input("Player Three, please hit the return key to roll the die.")
    playerThreeMove = random.randrange(2, 12)
    playerThreePosition += playerThreeMove
    print"Player Three rolls a {0}".format(playerTwoMove)
    if playerThreePosition % 20 == 6:
        playerThreeHasA = True
        playerThreeAText = "A "
    if playerThreePosition % 20 == 9:
        playerThreeHasB = True
        playerThreeBText = "B "
    if playerThreePosition % 20 == 13:
        playerThreeHasC = True
        playerThreeCText = "C "
    if playerThreePosition % 20 == 18:
        playerThreeHasD = True
        playerThreeDText = "D "
    if playerThreePosition > 80:
        playerThreePosition %= 80

    print"Player Three Has: {0}{1}{2}{3}".format(playerThreeAText, playerThreeBText, playerThreeCText, playerThreeDText)

    if playerThreePosition == playerOnePosition:
        playerOnePosition = 1
        playerOneHasA = False
        playerOneAText = ""
        playerOneHasB = False
        playerOneBText = ""
        playerOneHasC = False
        playerOneCText = ""
        playerOneHAsD = False
        playerOneDText = ""
        print "Player Three Has Bumped player One back to the first space! Player One Loses all letters!"

    if playerThreePosition == playerTwoPosition:
        playerTwoPosition = 1
        playerTwoHasA = False
        playerTwoAText = ""
        playerTwoHasB = False
        playerTwoBText = ""
        playerTwoHasC = False
        playerTwoCText = ""
        playerTwoHAsD = False
        playerTwoDText = ""
        print "Player Three Has Bumped player Two back to the first space! Player Two Loses all letters!"

    print playerOneStarter + " " * playerOnePosition + "*"
    print board
    print playerTwoStarter + " " * playerTwoPosition + "*"
    print playerThreeStarter + " " * playerThreePosition + "*"

    if playerThreeHasA and playerThreeHasB and playerThreeHasC and playerThreeHasD:
        print"Player Three wins!"
        print"Game Over"
        break

# ----------------------------------------------------------------------------------------------------------------------

while fourPlayers:
    dummy12 = raw_input("Player One, please hit the return key to roll the die.")
    playerOneMove = random.randrange(2, 12)
    playerOnePosition += playerOneMove
    print"Player One rolls a {0}".format(playerOneMove)
    if playerOnePosition % 20 == 6:
        playerOneHasA = True
        playerOneAText = "A "
    if playerOnePosition % 20 == 9:
        playerOneHasB = True
        playerOneBText = "B "
    if playerOnePosition % 20 == 13:
        playerOneHasC = True
        playerOneCText = "C "
    if playerOnePosition % 20 == 18:
        playerOneHasD = True
        playerOneDText = "D "
    if playerOnePosition > 80:
        playerOnePosition %= 80

    print"Player One Has: {0}{1}{2}{3}".format(playerOneAText, playerOneBText, playerOneCText, playerOneDText)

    if playerOnePosition == playerTwoPosition:
        playerTwoPosition = 1
        playerOneHasA = False
        playerOneAText = ""
        playerOneHasB = False
        playerOneBText = ""
        playerOneHasC = False
        playerOneCText = ""
        playerOneHAsD = False
        playerOneDText = ""
        print "Player Two Has Bumped player one back to the first space! Player One Loses all letters!"

    if playerOnePosition == playerThreePosition:
        playerThreePosition = 1
        playerThreeHasA = False
        playerThreeAText = ""
        playerThreeHasB = False
        playerThreeBText = ""
        playerThreeHasC = False
        playerThreeCText = ""
        playerThreeHAsD = False
        playerThreeDText = ""
        print "Player One Has Bumped player Three back to the first space! Player Three Loses all letters!"

    if playerOnePosition == playerFourPosition:
        playerFourPosition = 1
        playerFourHasA = False
        playerFourAText = ""
        playerFourHasB = False
        playerFourBText = ""
        playerFourHasC = False
        playerFourCText = ""
        playerFourHAsD = False
        playerFourDText = ""
        print "Player One Has Bumped player Four back to the first space! Player Four Loses all letters!"

    print playerOneStarter + " " * playerOnePosition + "*"
    print playerTwoStarter + " " * playerTwoPosition + "*"
    print board
    print playerThreeStarter + " " * playerThreePosition + "*"
    print playerFourStarter + " " * playerFourPosition + "*"

    if playerOneHasA and playerOneHasB and playerOneHasC and playerOneHasD:
        print"Player One wins!"
        print"Game Over"
        break

    dummy22 = raw_input("Player Two, please hit the return key to roll the die.")
    playerTwoMove = random.randrange(2, 12)
    playerTwoPosition += playerTwoMove
    print"Player Two rolls a {0}".format(playerTwoMove)
    if playerTwoPosition % 20 == 6:
        playerTwoHasA = True
        playerTwoAText = "A "
    if playerTwoPosition % 20 == 9:
        playerTwoHasB = True
        playerTwoBText = "B "
    if playerTwoPosition % 20 == 13:
        playerTwoHasC = True
        playerTwoCText = "C "
    if playerTwoPosition % 20 == 18:
        playerTwoHasD = True
        playerTwoDText = "D "
    if playerTwoPosition > 80:
        playerTwoPosition %= 80

    print"Player Two Has: {0}{1}{2}{3}".format(playerTwoAText, playerTwoBText, playerTwoCText, playerTwoDText)

    if playerTwoPosition == playerOnePosition:
        playerOnePosition = 1
        playerOneHasA = False
        playerOneAText = ""
        playerOneHasB = False
        playerOneBText = ""
        playerOneHasC = False
        playerOneCText = ""
        playerOneHAsD = False
        playerOneDText = ""
        print "Player Two Has Bumped player one back to the first space! Player One Loses all letters!"

    if playerTwoPosition == playerThreePosition:
        playerThreePosition = 1
        playerThreeHasA = False
        playerThreeAText = ""
        playerThreeHasB = False
        playerThreeBText = ""
        playerThreeHasC = False
        playerThreeCText = ""
        playerThreeHAsD = False
        playerThreeDText = ""
        print "Player Two Has Bumped player Three back to the first space! Player Three Loses all letters!"

    if playerTwoPosition == playerFourPosition:
        playerFourPosition = 1
        playerFourHasA = False
        playerFourAText = ""
        playerFourHasB = False
        playerFourBText = ""
        playerFourHasC = False
        playerFourCText = ""
        playerFourHAsD = False
        playerFourDText = ""
        print "Player Two Has Bumped player Four back to the first space! Player Four Loses all letters!"

    print playerOneStarter + " " * playerOnePosition + "*"
    print playerTwoStarter + " " * playerTwoPosition + "*"
    print board
    print playerThreeStarter + " " * playerThreePosition + "*"
    print playerFourStarter + " " * playerFourPosition + "*"

    if playerTwoHasA and playerTwoHasB and playerTwoHasC and playerTwoHasD:
        print"Player One wins!"
        print"Game Over"
        break

    dummy32 = raw_input("Player Three, please hit the return key to roll the die.")
    playerThreeMove = random.randrange(2, 12)
    playerThreePosition += playerThreeMove
    print"Player Three rolls a {0}".format(playerTwoMove)
    if playerThreePosition % 20 == 6:
        playerThreeHasA = True
        playerThreeAText = "A "
    if playerThreePosition % 20 == 9:
        playerThreeHasB = True
        playerThreeBText = "B "
    if playerThreePosition % 20 == 13:
        playerThreeHasC = True
        playerThreeCText = "C "
    if playerThreePosition % 20 == 18:
        playerThreeHasD = True
        playerThreeDText = "D "
    if playerThreePosition > 80:
        playerThreePosition %= 80

    print"Player Three Has: {0}{1}{2}{3}".format(playerThreeAText, playerThreeBText, playerThreeCText, playerThreeDText)

    if playerThreePosition == playerOnePosition:
        playerOnePosition = 1
        playerTwoHasA = False
        playerTwoAText = ""
        playerTwoHasB = False
        playerTwoBText = ""
        playerTwoHasC = False
        playerTwoCText = ""
        playerTwoHAsD = False
        playerTwoDText = ""
        print "Player Three Has Bumped player One back to the first space! Player One Loses all letters!"
    if playerThreePosition == playerTwoPosition:
        playerTwoPosition = 1
        playerTwoHasA = False
        playerTwoAText = ""
        playerTwoHasB = False
        playerTwoBText = ""
        playerTwoHasC = False
        playerTwoCText = ""
        playerTwoHAsD = False
        playerTwoDText = ""
        print "Player Three Has Bumped player Two back to the first space! Player Two Loses all letters!"
    if playerThreePosition == playerFourPosition:
        playerFourPosition = 1
        playerFourHasA = False
        playerFourAText = ""
        playerFourHasB = False
        playerFourBText = ""
        playerFourHasC = False
        playerFourCText = ""
        playerFourHAsD = False
        playerFourDText = ""
        print "Player Three Has Bumped player Four back to the first space! Player Four Loses all letters!"

    print playerOneStarter + " " * playerOnePosition + "*"
    print playerTwoStarter + " " * playerTwoPosition + "*"
    print board
    print playerThreeStarter + " " * playerThreePosition + "*"
    print playerFourStarter + " " * playerFourPosition + "*"

    if playerThreeHasA and playerThreeHasB and playerThreeHasC and playerThreeHasD:
        print"Player Three wins!"
        print"Game Over"
        break

    dummy42 = raw_input("Player Four, please hit the return key to roll the die.")
    playerFourMove = random.randrange(2, 12)
    playerFourPosition += playerFourMove
    print"Player Four rolls a {0}".format(playerTwoMove)
    if playerFourPosition % 20 == 6:
        playerFourHasA = True
        playerFourAText = "A "
    if playerFourPosition % 20 == 9:
        playerFourHasB = True
        playerFourBText = "B "
    if playerFourPosition % 20 == 13:
        playerFourHasC = True
        playerFourCText = "C "
    if playerFourPosition % 20 == 18:
        playerFourHasD = True
        playerFourDText = "D "
    if playerFourPosition > 80:
        playerFourPosition %= 80

    print"Player Three Has: {0}{1}{2}{3}".format(playerThreeAText, playerThreeBText, playerThreeCText, playerThreeDText)

    if playerFourPosition == playerOnePosition:
        playerOnePosition = 1
        playerOneHasA = False
        playerOneAText = ""
        playerOneHasB = False
        playerOneBText = ""
        playerOneHasC = False
        playerOneCText = ""
        playerOneHasD = False
        playerOnDText = ""
        print "Player Three Has Bumped player One back to the first space! Player One Loses all letters!"
    if playerFourPosition == playerTwoPosition:
        playerTwoPosition = 1
        playerTwoHasA = False
        playerTwoAText = ""
        playerTwoHasB = False
        playerTwoBText = ""
        playerTwoHasC = False
        playerTwoCText = ""
        playerTwoHAsD = False
        playerTwoDText = ""
        print "Player Three Has Bumped player Two back to the first space! Player Two Loses all letters!"
    if playerThreePosition == playerFourPosition:
        playerThreePosition = 1
        playerThreeHasA = False
        playerThreeAText = ""
        playerThreeHasB = False
        playerThreeBText = ""
        playerThreeHasC = False
        playerThreeCText = ""
        playerThreeHAsD = False
        playerThreeDText = ""
        print "Player Three Has Bumped player Four back to the first space! Player Four Loses all letters!"

    print playerOneStarter + " " * playerOnePosition + "*"
    print playerTwoStarter + " " * playerTwoPosition + "*"
    print board
    print playerThreeStarter + " " * playerThreePosition + "*"
    print playerFourStarter + " " * playerFourPosition + "*"

    if playerFourHasA and playerFourHasB and playerFourHasC and playerFourHasD:
        print"Player Four wins!"
        print"Game Over"
        break


