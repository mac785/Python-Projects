import random


def printBoard():
    print playerOneStarter + " " * playerOnePosition + "*"
    print board
    print playerTwoStarter + " " * playerTwoPosition + "*"


# strings you'll use to describe the board....
#                            12345678901234567890123456789012345678901234567890123456789012345678901234567890
board = "           -----A--B---C----D-------A--B---C----D-------A--B---C----D-------A--B---C----D--"
playerOneStarter = "Player 1: "
playerTwoStarter = "Player 2: "
playerOnePosition = 0
playerTwoPosition = 0
# Information about which chips player 1 has collected.
playerOneChips = 0
playerOneAText = ""
playerOneBText = ""
playerOneCText = ""
playerOneDText = ""
# Information about which chips player 2 has collected.
playerTwoChips = 0
playerTwoAText = ""
playerTwoBText = ""
playerTwoCText = ""
playerTwoDText = ""

print"Welcome to Collect Four (not to be confused with Connect Four).\nA two player game will now begin.\n"

while True:
    dummy1 = raw_input("Player One, please press the return key to roll the dice.")
    playerOneMove = random.randrange(2, 12)
    playerOnePosition += playerOneMove
    print"Player One rolls a {0}.".format(playerOneMove)
    if playerOnePosition % 20 == 6:
        playerOneChips |= 1
        playerOneAText = "A "
    if playerOnePosition % 20 == 9:
        playerOneChips |= 2
        playerOneBText = "B "
    if playerOnePosition % 20 == 13:
        playerOneChips |= 4
        playerOneCText = "C "
    if playerOnePosition % 20 == 18:
        playerOneChips |= 8
        playerOneDText = "D "
    if playerOnePosition > 80:
        playerOnePosition %= 80

    print"Player One Has: {0}{1}{2}{3}".format(playerOneAText, playerOneBText, playerOneCText, playerOneDText)

    if playerOneChips == 15:
        print"Player One Wins! Game Over. Get good m79+1."

    if playerOnePosition == playerTwoPosition:
        playerTwoPosition = 1
        playerTwoChips = 0
        playerTwoAText = ""
        playerTwoBText = ""
        playerTwoCText = ""
        playerTwoDText = ""
        print "Player Two Has Bumped player one back to the first space! Player One Loses all letters!"

        printBoard()

    dummy2 = raw_input("Player Two, please press the return key to roll the dice")
    playerTwoMove = random.randrange(2, 12)
    playerTwoPosition += playerTwoMove
    print"Player Two rolls a {0}".format(playerTwoMove)